<?php
die('No File/directory exist');

?>