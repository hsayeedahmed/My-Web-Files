# README #

wpsp_notes.txt contains information about pending tasks and future feature updates.